import express from "express";
import dotenv from "dotenv";
import crypto from "crypto";
import { initDB, sumMonth, topCategories, listMonth } from "./db.js";
import { parseExpense } from "./parser.js";
import { replyText } from "./whatsapp.js";

dotenv.config();
const app = express();
app.use(express.json({ verify: (req, res, buf) => { req.rawBody = buf; } }));
let db; initDB().then(d => db = d);

function safeEqual(a, b) { const A = Buffer.from(a||''); const B = Buffer.from(b||''); return A.length===B.length && crypto.timingSafeEqual(A,B); }
function verifySignature(req){ const s=req.get('x-hub-signature-256')||''; const secret=process.env.APP_SECRET; if(!secret) return true; const expected='sha256='+crypto.createHmac('sha256', secret).update(req.rawBody||Buffer.from('')).digest('hex'); return safeEqual(expected,s); }

app.get('/', (_,res)=> res.send('OK'));

app.get('/webhook', (req,res)=>{
  const mode=req.query['hub.mode']; const token=req.query['hub.verify_token']; const challenge=req.query['hub.challenge'];
  if(mode==='subscribe' && token===process.env.VERIFY_TOKEN) return res.status(200).send(challenge);
  return res.sendStatus(403);
});

app.post('/webhook', async (req,res)=>{
  try{
    if(!verifySignature(req)) return res.sendStatus(401);
    const body=req.body;
    if(body.object==='whatsapp_business_account'){
      for(const entry of body.entry||[]){
        for(const change of entry.changes||[]){
          const v=change.value||{}; const messages=v.messages||[];
          for(const msg of messages){
            const phone=msg.from; if(msg.type!=='text') continue; const raw=msg.text?.body||''; const text=raw.trim().toLowerCase();

            if(['saldo','total mes','total mês'].includes(text)){
              const total=await sumMonth(db, phone);
              await replyText(phone, `📊 Total do mês: R$ ${total.toFixed(2).replace('.',',')}`);
              continue;
            }
            if(text==='por categoria'){
              const rows=await topCategories(db, phone, 5);
              if(!rows.length) await replyText(phone,'Sem lançamentos neste mês.');
              else{
                const lines=rows.map(r=>`• ${r.category}: R$ ${Number(r.total).toFixed(2).replace('.',',')}`);
                await replyText(phone, '📊 Por categoria (mês):
'+lines.join('
'));
              }
              continue;
            }
            if(text.startsWith('exportar')){
              const d=new Date(); const yyyy=d.getUTCFullYear(); const mm=String(d.getUTCMonth()+1).padStart(2,'0');
              const month=`${yyyy}-${mm}`; const base=process.env.PUBLIC_BASE_URL;
              if(!base) await replyText(phone,'Defina PUBLIC_BASE_URL para gerar o link de exportação.');
              else await replyText(phone, `📁 Exportação do mês: ${base}/export?phone=${phone}&month=${month}`);
              continue;
            }
            const parsed=parseExpense(raw);
            if(!parsed||isNaN(parsed.amount)){
              await replyText(phone,'Não entendi o valor. Envie algo como:
• gastei 45,90 mercado
• R$120 combustível almoço 🙂');
              continue;
            }
            await db.run(`INSERT INTO expenses (wa_id, phone, text_raw, amount, category, description, tx_date)
                          VALUES (?,?,?,?,?,?, datetime('now'))`,
                          [msg.id, phone, raw, parsed.amount, parsed.category, parsed.description]);
            const confirm=`✅ Registrado: R$ ${parsed.amount.toFixed(2).replace('.',',')} • ${parsed.category}`+(parsed.description?` • ${parsed.description}`:'');
            await replyText(phone, confirm+'
Dica: mande "saldo" ou "por categoria".');
          }
        }
      }
    }
    return res.sendStatus(200);
  }catch(e){ console.error(e); return res.sendStatus(200); }
});

app.get('/export', async (req,res)=>{
  try{
    const phone=String(req.query.phone||'').trim(); const month=String(req.query.month||'').trim();
    if(!phone||!/^[0-9]{10,15}$/.test(phone)) return res.sendStatus(400);
    if(!/^\d{4}-\d{2}$/.test(month)) return res.sendStatus(400);
    const rows=await listMonth(db, phone, month);
    const header='data,valor,categoria,descricao,original
';
    const csv=header+rows.map(r=>[
      r.tx_date,
      Number(r.amount).toFixed(2).replace('.',','),
      r.category,
      (r.description||'').replace(/[
]+/g,' ').replace(/"/g,'""'),
      (r.text_raw||'').replace(/[
]+/g,' ').replace(/"/g,'""')
    ].map(v=>`"${v}"`).join(',')).join('
');
    res.setHeader('Content-Type','text/csv; charset=utf-8');
    res.setHeader('Content-Disposition',`attachment; filename="gastos-${phone}-${month}.csv"`);
    return res.status(200).send(csv);
  }catch(e){ console.error(e); return res.sendStatus(500); }
});

app.listen(process.env.PORT||3000, ()=> console.log(`Bot escutando na porta ${process.env.PORT||3000}`));
