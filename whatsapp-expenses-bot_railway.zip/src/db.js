import sqlite3 from "sqlite3";
import { open } from "sqlite";

export async function initDB() {
  const db = await open({ filename: "./expenses.sqlite", driver: sqlite3.Database });
  await db.exec(`
    CREATE TABLE IF NOT EXISTS expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      wa_id TEXT,
      phone TEXT,
      text_raw TEXT,
      amount REAL,
      category TEXT,
      description TEXT,
      tx_date TEXT,
      source TEXT DEFAULT 'whatsapp',
      created_at TEXT DEFAULT (datetime('now'))
    );
  `);
  return db;
}

export async function sumMonth(db, phone) {
  const row = await db.get(
    `SELECT IFNULL(SUM(amount),0) AS total
     FROM expenses
     WHERE phone = ?
       AND strftime('%Y-%m', tx_date) = strftime('%Y-%m','now')`,
    [phone]
  );
  return row.total || 0;
}

export async function topCategories(db, phone, limit = 5) {
  const rows = await db.all(
    `SELECT category, ROUND(SUM(amount),2) AS total
     FROM expenses
     WHERE phone = ?
       AND strftime('%Y-%m', tx_date) = strftime('%Y-%m','now')
     GROUP BY category
     ORDER BY total DESC
     LIMIT ?`,
    [phone, limit]
  );
  return rows;
}

export async function listMonth(db, phone, ym) {
  const rows = await db.all(
    `SELECT tx_date, amount, category, description, text_raw
     FROM expenses
     WHERE phone = ?
       AND strftime('%Y-%m', tx_date) = ?
     ORDER BY tx_date DESC`,
    [phone, ym]
  );
  return rows;
}
