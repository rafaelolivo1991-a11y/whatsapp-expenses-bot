export function parseExpense(text) {
  const raw = text.trim();
  const m = raw.match(/(?:^|)(?:gastei|gasto|paguei|compra|despesa)?\s*R?\$?\s*([\d\.]*\d(?:[,\.]\d{1,2})?)\s*(.*)$/i);
  if (!m) return null;
  let amountStr = (m[1] || "").replace(/\./g, "").replace(",", ".");
  const amount = parseFloat(amountStr);
  const desc = (m[2] || "").trim();

  const cats = [
    { name: "mercado", keys: ["mercado", "supermercado", "compras"] },
    { name: "combustivel", keys: ["combustível", "combustivel", "gasolina", "diesel", "etanol", "posto"] },
    { name: "alimentacao", keys: ["almoço", "almoco", "jantar", "lanche", "restaurante", "pizza"] },
    { name: "transporte", keys: ["uber", "taxi", "ônibus", "onibus", "pedágio", "pedagio"] },
    { name: "saude", keys: ["farmácia", "farmacia", "consulta", "remédio", "remedio"] },
    { name: "outros", keys: [] }
  ];
  let category = "outros";
  const dl = desc.toLowerCase();
  for (const c of cats) { if (c.keys.some(k => dl.includes(k))) { category = c.name; break; } }
  return { amount, description: desc || null, category };
}
