import axios from "axios";
import dotenv from "dotenv";
dotenv.config();
const GRAPH = `https://graph.facebook.com/${process.env.GRAPH_API_VERSION}`;
export async function replyText(to, body) {
  const url = `${GRAPH}/${process.env.WA_PHONE_NUMBER_ID}/messages`;
  const payload = { messaging_product: "whatsapp", to, text: { body } };
  await axios.post(url, payload, {
    headers: { Authorization: `Bearer ${process.env.CLOUD_API_TOKEN}`, "Content-Type": "application/json" }
  });
}
